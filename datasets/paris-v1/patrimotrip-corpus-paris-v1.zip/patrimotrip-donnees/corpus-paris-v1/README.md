# Corpus PatrimoTrip AI — Paris v1

Ce premier corpus contient 10 sites, 30 documents sourcés, 840 passages et 10 images de référence. Il sert à développer et tester la recherche documentaire. Il n'est pas encore un dataset d'entraînement ni un jeu d'évaluation indépendant.

## Sites couverts

| Site | Identifiant | Documents | Information de visite |
|---|---|---:|---|
| tour Eiffel | Q243 | 3 | Horaires et tarifs à vérifier |
| palais du Louvre | Q1075988 | 3 | Horaires et tarifs à vérifier |
| cathédrale Notre-Dame de Paris | Q2981 | 3 | Horaires et tarifs à vérifier |
| arc de triomphe de l'Étoile | Q64436 | 3 | Horaires et tarifs à vérifier |
| Panthéon | Q188856 | 3 | Horaires et tarifs à vérifier |
| basilique du Sacré-Cœur de Montmartre | Q28785 | 3 | Horaires et tarifs à vérifier |
| palais Garnier | Q187840 | 3 | Horaires et tarifs à vérifier |
| Sainte-Chapelle | Q193193 | 3 | Horaires et tarifs à vérifier |
| hôtel des Invalides | Q188977 | 3 | Horaires et tarifs à vérifier |
| place de la Concorde | Q189503 | 3 | Horaires et tarifs à vérifier |

## Fichiers

- `sites.json` : identités, coordonnées, liens, relation avec les lieux de visite et données manquantes.
- `documents.jsonl` : textes normalisés, sections, source, date, licence et empreinte.
- `passages.jsonl` : passages de 1 400 caractères maximum, avec recouvrement d'environ 200 caractères, prêts à indexer. Ce découpage est un réglage initial à évaluer, pas une optimisation mesurée.
- `images.json` : 10 références et métadonnées de licence. Les références additionnelles Wikidata restent des candidats dans `sites.json`.
- `images-locales.json` et `images/` : vignettes téléchargées, empreintes et notes de revue visuelle.
- `correspondances-a-verifier.json` : toutes les fiches touristiques acceptées comme candidates, avec leur provenance. Elles ne sont pas toutes fusionnées.
- `quarantaine.json` : fiche Palais Garnier présentant un écart de 3 559 mètres, exclue de l'index.
- `manifest.json` : versions des entrées, paramètres et compteurs.
- `ATTRIBUTIONS.md` : références nécessaires à la réutilisation des textes et images.

## Règles de préparation

Les extraits Wikipédia ont été normalisés en Unicode NFC. Les espaces ont été harmonisés ; les sections bibliographiques et de navigation ont été écartées de l'index. Les données brutes sont conservées dans le dossier d'échantillons et accompagnent l'archive reproductible.

Pour un site, une seule fiche touristique est indexée : la plus récemment mise à jour parmi les candidats situés à moins de 500 mètres des coordonnées de référence. La distance départage les dates égales. Le seuil sert au tri et ne prouve pas l'identité. Les alternatives restent disponibles pour la revue. La sélection ne garantit ni l'exactitude ni l'actualité des faits.

Le musée du Louvre est traité comme un lieu de visite lié au palais du Louvre, pas comme une identité interchangeable. La fiche de la place de la Concorde date de 2024 : sa fraîcheur est signalée.

Les notices Mérimée apportent également des informations de protection et de dénomination lorsque l'historique est vide. Elles ne sont pas artificiellement complétées.

Les horaires, les tarifs, l'heure limite d'entrée et les durées estimées restent `null`. Une valeur nulle ne signifie ni gratuité, ni ouverture permanente.

## Citations

Chaque passage renvoie à son document, sa section et un intervalle exact de caractères dans le texte normalisé. Les documents Wikipédia possèdent un lien permanent vers la révision téléchargée. Les notices Mérimée conservent leur référence et leur date de mise à jour. Les fiches touristiques conservent leur URI, leur producteur et l'URL de l'export.

Ces références permettent de retrouver la source. Elles ne démontrent pas à elles seules que toute réponse future sera correcte : il faudra contrôler que les passages soutiennent chaque affirmation.

## Images et limites

Les 10 vignettes ont été examinées : leurs sujets sont plausiblement cohérents avec les sites annoncés. La photo du Louvre montre une partie du palais, celle des Invalides est aérienne et celle de la Concorde est une vue panoramique éloignée. Ces limites sont enregistrées.

Une image par site ne suffit pas à mesurer la reconnaissance. Il faudra des vues supplémentaires et des images de test distinctes. Les conditions de licence doivent être appliquées par fichier ; la revue visuelle ne constitue pas une garantie sur les droits.

## Reproduction et contrôles

Avec Python 3, depuis le dossier parent :

```bash
python preparer_corpus.py
python verifier_corpus.py
```

La préparation fonctionne hors ligne sur les six échantillons conservés, sans dépendance tierce. Elle recrée les fichiers de données du corpus ; conserver séparément les futures annotations manuelles. Elle ne touche pas aux fichiers de l'application.

Les 7 fichiers de données générés ont été reconstruits deux fois avec des empreintes identiques. Les contrôles vérifient les identifiants, la provenance, les références, les offsets, la couverture du texte, l'exclusion de la quarantaine et les empreintes des images.

Pour obtenir ou rafraîchir les vignettes (réseau nécessaire) :

```bash
python telecharger_images_corpus.py
```

Ce script recrée le relevé des images locales et remet leur revue à « pending » ; préserver les annotations avant de le relancer.

## Ce qui reste à faire

- Vérifier les correspondances et les faits choisis pour l'évaluation.
- Compléter horaires et tarifs depuis des sources appropriées, en conservant date et provenance.
- Ajouter des photos de plusieurs angles et constituer un jeu de test distinct.
- Tester la recherche textuelle et visuelle avant de choisir les modèles et la base vectorielle.

Aucun fine-tuning, modèle vision-langage ni calcul de parcours n'est validé à ce stade. La petite taille du corpus permet d'expérimenter sans télécharger un dataset massif ; les performances sur la machine personnelle restent à mesurer.
