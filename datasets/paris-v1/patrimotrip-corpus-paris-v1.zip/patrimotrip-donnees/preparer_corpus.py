"""Build a traceable Paris corpus from the existing, frozen research samples.

Standard library only. No source download, model, or repository modification.
"""
import hashlib
import html
import json
import pathlib
import re
import unicodedata

ROOT = pathlib.Path(__file__).resolve().parent
INPUT = ROOT / "echantillons"
OUTPUT = ROOT / "corpus-paris-v1"
OUTPUT.mkdir(exist_ok=True)
MAX_DISTANCE_M = 500  # Screening threshold, not proof of identity.
CHUNK_LENGTH = 1400
OVERLAP = 200


def read(name):
    return json.loads((INPUT / name).read_text(encoding="utf-8"))


def clean(value):
    text = html.unescape(str(value or ""))
    text = re.sub(r"<[^>]*>", "", text)
    return unicodedata.normalize("NFC", re.sub(r"\s+", " ", text)).strip()


def digest(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()[:16]


def save(name, value, lines=False):
    if lines:
        text = "".join(json.dumps(v, ensure_ascii=False, sort_keys=True) + "\n" for v in value)
    else:
        text = json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    (OUTPUT / name).write_text(text, encoding="utf-8")


def wikipedia_sections(text):
    # Remove navigational appendices; preserve source snapshots separately.
    excluded = {"notes", "références", "notes et références", "annexes", "voir aussi",
                "bibliographie", "liens externes", "articles connexes", "sources"}
    sections, path, paragraphs = [], [], []
    excluded_level = None

    def flush():
        content = clean("\n".join(paragraphs))
        if content:
            sections.append({"path": [x[1] for x in path] or ["Introduction"], "text": content})
        paragraphs.clear()

    for line in text.splitlines():
        match = re.match(r"^(={2,6})\s*(.*?)\s*\1\s*$", line)
        if match:
            flush()
            level, title = len(match[1]), clean(match[2])
            if excluded_level is not None and level <= excluded_level:
                excluded_level = None
            path = [x for x in path if x[0] < level] + [(level, title)]
            if title.casefold() in excluded and excluded_level is None:
                excluded_level = level
        elif excluded_level is None:
            paragraphs.append(line)
    flush()
    return sections


sites_raw = read("paris-sites.json")
tourism = {x["site_id"]: x for x in read("paris-datatourisme-correspondances.json")}
heritage = {x["Reference"]: x for x in read("paris-merimee-notices.json")}
wiki = {x["site_id"]: x for x in read("paris-corpus-wikipedia.json")}
image_metadata = {clean(x["title"].replace("_", " ")): x for x in read("images-licences.json")}
catalogue = read("datatourisme-catalogue-actuel.json")
tourism_resource = next(r for r in catalogue["resources"] if "idf" in r.get("title", "").lower())
sites, documents, passages, images, quarantine, review = [], [], [], [], [], []


def add_document(site_id, source, sections):
    sections = [s for s in sections if s["text"]]
    text, ranges = "", []
    for section in sections:
        if text:
            text += "\n\n"
        start = len(text)
        text += section["text"]
        ranges.append({"path": section["path"], "start": start, "end": len(text)})
    if not text:
        return
    doc_id = source["source_id"] + ":" + digest(text)
    documents.append({"document_id": doc_id, "site_id": site_id, "source": source,
                      "text": text, "sections": ranges, "content_sha256": hashlib.sha256(text.encode()).hexdigest()})
    for section in ranges:
        start = section["start"]
        while start < section["end"]:
            end = min(start + CHUNK_LENGTH, section["end"])
            if end < section["end"]:
                boundary = text.rfind(" ", start + CHUNK_LENGTH // 2, end)
                if boundary > start:
                    end = boundary
            passages.append({"passage_id": f"{doc_id}:{start}-{end}", "document_id": doc_id,
                             "site_id": site_id, "section_path": section["path"], "start": start,
                             "end": end, "text": text[start:end], "citation_url": source["url"],
                             "source_type": source["type"], "license": source["license"]})
            if end == section["end"]:
                break
            start = end - OVERLAP
            # Avoid starting inside a word; maintain exact offsets in processed text.
            space = text.find(" ", start, end)
            if space != -1:
                start = space + 1


for site in sites_raw:
    site_id = site["id"]
    candidates = tourism[site_id]["candidates"]
    accepted = []
    for candidate in candidates:
        if candidate["distance_from_wikidata_m"] > MAX_DISTANCE_M:
            quarantine.append({"site_id": site_id, "reason": "geographic_discrepancy",
                               "threshold_m": MAX_DISTANCE_M, "record": candidate})
        else:
            accepted.append(candidate)
    assert accepted, f"No tourist candidate for {site_id}"
    # Prefer newer records; distance only breaks ties. Related visiting places
    # remain explicit and never replace the monument's identity.
    accepted.sort(key=lambda c: (c["Date_de_mise_a_jour"], -c["distance_from_wikidata_m"]), reverse=True)
    primary = accepted[0]
    relation = "related_museum" if site_id == "Q1075988" else "same_site_candidate"
    coordinate = site["coordinates"][0]
    record = {
        "site_id": site_id, "name": clean(site["name"]), "city": "Paris", "country": "France",
        "coordinates": {"latitude": coordinate["latitude"], "longitude": coordinate["longitude"],
                        "source_url": site["source"], "verified_on_site": False},
        "official_website_candidates": site["official_websites"],
        "reference_image_candidates": site["images"],
        "wikidata": {"id": site_id, "url": site["source"], "retrieved_at": site["retrieved_at"], "license": "CC0"},
        "merimee_ids": site["merimee_ids"],
        "tourist_record": {"uri": primary["URI_ID_du_POI"], "name": clean(primary["Nom_du_POI"]),
                           "relation": relation, "address": clean(primary["Adresse_postale"]),
                           "updated_at": primary["Date_de_mise_a_jour"],
                           "publisher": primary["Createur_de_la_donnee"],
                           "distance_from_wikidata_m": primary["distance_from_wikidata_m"],
                           "identity_status": "candidate_not_fully_verified",
                           "alternative_uris": [r["URI_ID_du_POI"] for r in accepted[1:]]},
        "visit_constraints": {"opening_hours": None, "last_admission": None, "ticket_prices": None,
                              "estimated_visit_minutes": None, "status": "needs_verified_sources"},
        "warnings": ["Opening hours, prices and visit duration are not established."],
    }
    if len(accepted) > 1:
        record["warnings"].append("Multiple tourist records; one chosen for indexing, alternatives retained for review.")
    if relation == "related_museum":
        record["warnings"].append("The Louvre palace and museum have distinct identities and visiting conditions.")
    if primary["Date_de_mise_a_jour"] < "2025-01-01":
        record["warnings"].append("Tourist record predates 2025; update needed before practical use.")
    sites.append(record)
    review.append({"site_id": site_id, "primary_uri": primary["URI_ID_du_POI"],
                   "selection_rule": "newest_update_then_nearest_within_500m",
                   "relation": relation, "kept_candidates": accepted, "status": "needs_identity_review"})

    article = wiki[site_id]
    assert article.get("text") and article.get("revisions"), f"Missing article provenance: {site_id}"
    revision = article["revisions"][0]
    add_document(site_id, {"source_id": f"wikipedia:{site_id}:{revision['revid']}", "type": "wikipedia",
                          "title": article["title"], "url": f"https://fr.wikipedia.org/w/index.php?oldid={revision['revid']}",
                          "article_url": article["url"], "revision_id": revision["revid"],
                          "updated_at": revision["timestamp"], "license": "CC BY-SA 4.0",
                          "license_url": article["license"]["url"], "attribution": "Contributeurs de Wikipédia",
                          "history_url": article["url"] + "?action=history"}, wikipedia_sections(article["text"]))

    for reference in site["merimee_ids"]:
        notice = heritage[reference]
        fields = ["Titre_editorial_de_la_notice", "Commune_forme_index", "Denomination_de_l_edifice",
                  "Auteur_de_l_edifice", "Siecle_de_la_campagne_principale_de_construction",
                  "Date_et_typologie_de_la_protection", "Precision_de_la_protection"]
        sections = [{"path": ["Notice patrimoniale"], "text": "\n".join(
            f"{key}: {clean(notice[key])}" for key in fields if notice.get(key))}]
        for key in ["Historique", "Description_de_l_edifice"]:
            if clean(notice.get(key)):
                sections.append({"path": [key], "text": clean(notice[key])})
        add_document(site_id, {"source_id": f"merimee:{reference}", "type": "merimee",
                              "title": notice["Titre_editorial_de_la_notice"],
                              "url": f"https://pop.culture.gouv.fr/notice/merimee/{reference}",
                              "reference": reference, "publisher": "Ministère de la Culture",
                              "updated_at": notice["Date_de_la_derniere_mise_a_jour"],
                              "license": "Licence Ouverte 2.0", "license_evidence_url": "https://www.data.gouv.fr/api/1/datasets/5af120e5b595087cfabcde81/",
                              "copyright_notice": notice["Copyright"]}, sections)

    add_document(site_id, {"source_id": "datatourisme:" + digest(primary["URI_ID_du_POI"]),
                          "type": "datatourisme", "title": primary["Nom_du_POI"],
                          "url": primary["URI_ID_du_POI"], "publisher": primary["Createur_de_la_donnee"],
                          "updated_at": primary["Date_de_mise_a_jour"], "license": "Licence Ouverte",
                          "license_evidence_url": "https://www.datatourisme.fr/utiliser-les-donnees/",
                          "export_url": tourism_resource["url"], "relation_to_site": relation},
                 [{"path": ["Présentation touristique"], "text": clean(primary["Description"])}])

    # The existing Commons audit covers the first P18 image of each site.
    # Additional filenames remain candidates in sites.json until audited.
    for filename in site["images"][:1]:
        metadata = image_metadata[clean("File:" + filename.replace("_", " "))]
        images.append({"image_id": digest(metadata["page"]), "site_id": site_id, "title": metadata["title"],
                       "page_url": metadata["page"], "original_url": metadata["url"],
                       "thumbnail_url": metadata["thumbnail_url"], "license": metadata["license"],
                       "license_url": metadata["license_url"], "author": clean(metadata["artist"]),
                       "credit": clean(metadata["credit"]), "attribution_required": metadata["attribution_required"],
                       "restrictions": metadata["restrictions"], "visual_review": "pending",
                       "rights_review": "pending", "local_thumbnail": None})

save("sites.json", sites)
save("documents.jsonl", documents, lines=True)
save("passages.jsonl", passages, lines=True)
save("images.json", images)
save("quarantaine.json", quarantine)
save("correspondances-a-verifier.json", review)
input_names = ["paris-sites.json", "paris-datatourisme-correspondances.json", "paris-merimee-notices.json",
               "paris-corpus-wikipedia.json", "images-licences.json", "datatourisme-catalogue-actuel.json"]
manifest = {"version": "paris-v1", "input_sha256": {n: hashlib.sha256((INPUT / n).read_bytes()).hexdigest() for n in input_names},
            "builder_sha256": hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
            "parameters": {"geographic_screening_m": MAX_DISTANCE_M, "chunk_characters": CHUNK_LENGTH,
                           "overlap_characters": OVERLAP},
            "counts": {"sites": len(sites), "documents": len(documents), "passages": len(passages),
                       "images": len(images), "quarantined_records": len(quarantine)},
            "readiness": {"text_indexing": True, "factual_validation_complete": False,
                          "visual_recognition_evaluated": False, "visit_planning": False}}
save("manifest.json", manifest)
print(json.dumps(manifest["counts"], ensure_ascii=False))
