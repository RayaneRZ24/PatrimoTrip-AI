"""Validate referential integrity, provenance, and passage coverage offline."""
import hashlib
import json
import pathlib

P = pathlib.Path(__file__).resolve().parent / "corpus-paris-v1"
sites = json.loads((P / "sites.json").read_text())
documents = [json.loads(line) for line in (P / "documents.jsonl").read_text().splitlines()]
passages = [json.loads(line) for line in (P / "passages.jsonl").read_text().splitlines()]
ids = {s["site_id"] for s in sites}
by_id = {d["document_id"]: d for d in documents}
assert len(ids) == len(sites) == 10
assert len(by_id) == len(documents)
assert len({p["passage_id"] for p in passages}) == len(passages)
for document in documents:
    assert document["site_id"] in ids
    assert document["source"]["url"].startswith("https://")
    assert document["source"]["license"] and document["text"].strip()
    assert document["content_sha256"] == hashlib.sha256(document["text"].encode()).hexdigest()
for passage in passages:
    document = by_id[passage["document_id"]]
    assert passage["site_id"] == document["site_id"]
    assert 0 <= passage["start"] < passage["end"] <= len(document["text"])
    assert passage["text"] == document["text"][passage["start"]:passage["end"]]
    assert len(passage["text"]) <= 1400
    assert passage["citation_url"] == document["source"]["url"]
for document in documents:
    covered = [False] * len(document["text"])
    for passage in passages:
        if passage["document_id"] == document["document_id"]:
            covered[passage["start"]:passage["end"]] = [True] * (passage["end"] - passage["start"])
    assert all(covered[i] or char.isspace() for i, char in enumerate(document["text"]))
for site in sites:
    assert all(site["visit_constraints"][key] is None for key in
               ["opening_hours", "last_admission", "ticket_prices", "estimated_visit_minutes"])
quarantine = json.loads((P / "quarantaine.json").read_text())
excluded = {q["record"]["URI_ID_du_POI"] for q in quarantine}
assert not excluded.intersection(d["source"]["url"] for d in documents)
assets = json.loads((P / "images-locales.json").read_text())
assert len(assets) == 10
for asset in assets:
    assert asset["site_id"] in ids and asset.get("relative_path")
    path = (P / asset["relative_path"]).resolve()
    assert path.is_relative_to(P.resolve())
    assert asset["sha256"] == hashlib.sha256(path.read_bytes()).hexdigest()
print(f"OK: {len(sites)} sites, {len(documents)} documents, {len(passages)} passages, {len(assets)} images.")
print("Provenance, references, offsets, text coverage, quarantine exclusion, and image integrity verified.")
