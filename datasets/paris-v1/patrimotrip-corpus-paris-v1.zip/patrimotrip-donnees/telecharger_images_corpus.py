"""Download selected reference thumbnails; keep provenance and review status."""
import hashlib,json,pathlib,urllib.request,urllib.parse
P=pathlib.Path(__file__).resolve().parent/'corpus-paris-v1';D=P/'images';D.mkdir(exist_ok=True)
records=json.loads((P/'images.json').read_text())
assets=[]
for record in records:
 name=record['site_id']+pathlib.Path(urllib.parse.urlsplit(record['thumbnail_url']).path).suffix
 path=D/name
 try:
  if not path.exists():
   with urllib.request.urlopen(urllib.request.Request(record['thumbnail_url'],headers={'User-Agent':'PatrimoTripAI/0.1 (academic feasibility study)'}),timeout=25) as r:
    content_type=r.headers.get('Content-Type','');body=r.read(3000001)
   if not content_type.startswith('image/') or len(body)>3000000:raise ValueError('Unexpected format or size above 3 MB')
   path.write_bytes(body)
  body=path.read_bytes()
  assets.append({'image_id':record['image_id'],'site_id':record['site_id'],'relative_path':'images/'+name,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'visual_review':'pending','rights_review':'pending','source_page':record['page_url']})
  print(record['site_id'],'OK',len(body),flush=True)
 except Exception as e:
  assets.append({'image_id':record['image_id'],'site_id':record['site_id'],'download_error':str(e),'visual_review':'pending','rights_review':'pending'})
  print(record['site_id'],str(e),flush=True)
(P/'images-locales.json').write_text(json.dumps(assets,ensure_ascii=False,indent=2)+'\n')
